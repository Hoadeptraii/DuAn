/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BangPanel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author dauxu
 */
public class BangDichVuDao {
  public static List<BangDichVuUse> ls = new ArrayList<>();
     DefaultTableModel model = new DefaultTableModel();
     
      public  List<BangDichVuUse> getAllSanPham() throws SQLException{
        List<BangDichVuUse> ls = new ArrayList<>();
        Connection conn = null;
         Statement sttm = null;
        ResultSet rs = null;
          try {
              String sSQL = "SELECT Reception.ID, Customers.hoten,Cars.tenxe,Reception.[thoigian],Reception.[timehen]\n" +
"FROM Reception, Cars, Customers ";
            conn = data.data.getDBConnect();
            sttm = conn.createStatement();
            rs = sttm.executeQuery(sSQL);
            while (rs.next()){
                BangDichVuUse sp = new BangDichVuUse();
                sp.setID(rs.getString(1));
                sp.setKH(rs.getString(2));
                sp.setIdcar(rs.getString(3));
                sp.setTime(rs.getString(4));
                sp.setTimeout(rs.getString(5));
                ls.add(sp);           
          }
          } catch (Exception e) {
                   System.err.println("Error : "+e.toString());
                  }finally{
            try {
                conn.close();
                sttm.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
                   return ls;
          
      }
        

}
