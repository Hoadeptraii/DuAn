/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BangPanel;

/**
 *
 * @author dauxu
 */
public class BangDichVuUse {
    private  String ID ;
    private String KH ;
    private  String idcar ;
    private String time;
    private String Timeout ; 

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getKH() {
        return KH;
    }

    public void setKH(String KH) {
        this.KH = KH;
    }

    public String getIdcar() {
        return idcar;
    }

    public void setIdcar(String idcar) {
        this.idcar = idcar;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTimeout() {
        return Timeout;
    }

    public void setTimeout(String Timeout) {
        this.Timeout = Timeout;
    }

    public BangDichVuUse(String ID, String KH, String idcar, String time, String Timeout) {
        this.ID = ID;
        this.KH = KH;
        this.idcar = idcar;
        this.time = time;
        this.Timeout = Timeout;
    }

    public BangDichVuUse() {
    }

}