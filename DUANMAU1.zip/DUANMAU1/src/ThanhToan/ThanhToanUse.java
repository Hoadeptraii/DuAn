/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThanhToan;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author dauxu
 */
public class ThanhToanUse {
    public static List<ThanhtoanDao> ls = new ArrayList<>();
     DefaultTableModel model = new DefaultTableModel();
     
      public  List<ThanhtoanDao> getAllSanPham() throws SQLException{
        List<ThanhtoanDao> ls = new ArrayList<>();
        Connection conn = null;
         Statement sttm = null;
        ResultSet rs = null;
          try {
              String sSQL = "SELECT HoaDon.idHD, Customers.hoten,Cars.TinhTrang,Repair.idRepair,Customers.sodt,HoaDon.TongTien\n" +
"FROM HoaDon, Cars, Customers, Repair  ";
            conn = data.data.getDBConnect();
            sttm = conn.createStatement();
            rs = sttm.executeQuery(sSQL);
            while (rs.next()){
                ThanhtoanDao sp = new ThanhtoanDao();
                sp.setMaHD(rs.getString(1));
                sp.setHoten(rs.getString(2));
                sp.setTinhTrang(rs.getString(3));
                sp.setMaPhieuNhan(rs.getString(4));
                sp.setSodienthoai(rs.getString(5));
                 sp.setTongTien(rs.getString(6));
                ls.add(sp);           
          }
          } catch (Exception e) {
                   System.err.println("Error : "+e.toString());
                  }finally{
            try {
                conn.close();
                sttm.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
                   return ls;
    
      }
}
