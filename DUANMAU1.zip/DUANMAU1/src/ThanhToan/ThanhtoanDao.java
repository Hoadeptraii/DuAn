/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThanhToan;

/**
 *
 * @author dauxu
 */
public class ThanhtoanDao {
    private String maHD ;
    private String hoten ;
    private String TinhTrang  ;
    private String MaPhieuNhan ;
     private String Sodienthoai ;
      private String TongTien ;

    public ThanhtoanDao() {
    }

    public ThanhtoanDao(String maHD, String hoten, String TinhTrang, String MaPhieuNhan, String Sodienthoai, String TongTien) {
        this.maHD = maHD;
        this.hoten = hoten;
        this.TinhTrang = TinhTrang;
        this.MaPhieuNhan = MaPhieuNhan;
        this.Sodienthoai = Sodienthoai;
        this.TongTien = TongTien;
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getTinhTrang() {
        return TinhTrang;
    }

    public void setTinhTrang(String TinhTrang) {
        this.TinhTrang = TinhTrang;
    }

    public String getMaPhieuNhan() {
        return MaPhieuNhan;
    }

    public void setMaPhieuNhan(String MaPhieuNhan) {
        this.MaPhieuNhan = MaPhieuNhan;
    }

    public String getSodienthoai() {
        return Sodienthoai;
    }

    public void setSodienthoai(String Sodienthoai) {
        this.Sodienthoai = Sodienthoai;
    }

    public String getTongTien() {
        return TongTien;
    }

    public void setTongTien(String TongTien) {
        this.TongTien = TongTien;
    }
      
}
