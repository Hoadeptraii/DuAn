/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThanhToan;

/**
 *
 * @author dauxu
 */
public class ThemKhachHangUser {
    private String hoten;
    private String sdt ;
    private String tenXe; 

    public ThemKhachHangUser() {
    }

    public ThemKhachHangUser(String hoten, String sdt, String tenXe) {
        this.hoten = hoten;
        this.sdt = sdt;
        this.tenXe = tenXe;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getTenXe() {
        return tenXe;
    }

    public void setTenXe(String tenXe) {
        this.tenXe = tenXe;
    }
    
    
}
