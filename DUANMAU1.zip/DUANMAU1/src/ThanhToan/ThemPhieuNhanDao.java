/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThanhToan;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author dauxu
 */
public class ThemPhieuNhanDao {

    public static List<ThemPhieuNhanUse> ls = new ArrayList<>();
    DefaultTableModel modelll = new DefaultTableModel();

    public List<ThemPhieuNhanUse> getAllSanPham() throws SQLException {
        List<ThemPhieuNhanUse> ls = new ArrayList<>();
        Connection conn = null;
        Statement sttm = null;
        ResultSet rs = null;
        try {
            String sSQL = "SELECT Reception.ID, Customers.hoten, Customers.sodt, Cars.tenxe,Reception.thoigian , Reception.timehen,Cars.TinhTrang,Supplies.tenncc,Supplies.soLuong,Repair.tongTien,Repair.Noidung \n "
                    + "FROM Reception"
                    + " JOIN Cars ON Cars.idcar =  Reception.idcar "
                    + " JOIN Customers ON Customers.makh = Cars.makh "
                    + " JOIN Repair ON Reception.ID = Repair.ID "
                    + " JOIN Supplies ON Repair.idSupplies = Supplies.idSupplies ";
            conn = data.data.getDBConnect();
            sttm = conn.createStatement();
            rs = sttm.executeQuery(sSQL);
            while (rs.next()) {
                ThemPhieuNhanUse sp = new ThemPhieuNhanUse();
                sp.setIdRecep(rs.getString(1));
                sp.setTenkh(rs.getString(2));
                sp.setSdt(rs.getString(3));
                sp.setXe(rs.getString(4));
                sp.setTimevao(rs.getString(5));
                sp.setTimehen(rs.getString(6));
                sp.setTinhTrang(rs.getString(7));
                sp.setLinhKien(rs.getString(8));
                sp.setSoluong(rs.getInt(9));
                sp.setTongTien(rs.getDouble(10));
                sp.setNoidung(rs.getString(11));
                ls.add(sp);
            }
        } catch (Exception e) {
            System.err.println("Error : " + e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
        return ls;

    }
}
